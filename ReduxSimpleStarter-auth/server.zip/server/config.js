module.exports = {
  goldcoin: "SwimSoftlyAsYouCan,WhileIWatchTheSunSetInTheDistance..?.!"
}
